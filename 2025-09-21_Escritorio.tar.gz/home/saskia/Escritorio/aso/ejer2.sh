#!/bin/bash

#Creamos archivo
touch listado.txt

#Listamos /etc y lo guardamos en archivo
ls -a /etc > listado.txt

#mostramos contenido de archivo
cat listado.txt


