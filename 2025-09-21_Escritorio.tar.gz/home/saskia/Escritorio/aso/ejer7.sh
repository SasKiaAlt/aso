#!/bin/bash

[ $# -eq 1 ] && [ -d "$1" ] || { echo "Uso: $0 <directorio_valido>"; exit 1; }

fecha=$(date +%F)
nombre=$(basename "$1")

tar -czf "${fecha}_${nombre}.tar.gz" "$1" && echo "Archivo creado: ${fecha}_${nombre}.tar.gz"


