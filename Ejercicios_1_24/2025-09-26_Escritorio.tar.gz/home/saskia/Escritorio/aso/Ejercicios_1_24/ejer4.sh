#!/bin/bash

read -p "Dime un primer número: " num1
read -p "Dime un segundo número: " num2

echo "El primer número es: $num1"
echo "El segundo número es: $num2"



